export type Book = {
  id: number;
  title: string;
  author: string;
  price: number;
  category: string;
  rating: number;
  description: string;
  coverFrom: string;
  coverTo: string;
};

export const categories: string[] = [
  "All",
  "Fiction",
  "Non-Fiction",
  "Science",
  "History",
  "Self-Help",
  "Children",
];

export const books: Book[] = [
  {
    id: 1,
    title: "The Silent Patient",
    author: "Alex Michaelides",
    price: 14.99,
    category: "Fiction",
    rating: 4.5,
    description:
      "A psychological thriller about a woman who shoots her husband and then never speaks again.",
    coverFrom: "oklch(0.45 0.16 320)",
    coverTo: "oklch(0.3 0.14 300)",
  },
  {
    id: 2,
    title: "Atomic Habits",
    author: "James Clear",
    price: 19.49,
    category: "Self-Help",
    rating: 5,
    description:
      "An easy and proven way to build good habits and break bad ones, one tiny change at a time.",
    coverFrom: "oklch(0.55 0.14 165)",
    coverTo: "oklch(0.38 0.12 170)",
  },
  {
    id: 3,
    title: "Sapiens",
    author: "Yuval Noah Harari",
    price: 22.0,
    category: "History",
    rating: 4.5,
    description:
      "A brief history of humankind, exploring how Homo sapiens came to dominate the planet.",
    coverFrom: "oklch(0.6 0.13 35)",
    coverTo: "oklch(0.42 0.12 45)",
  },
  {
    id: 4,
    title: "A Brief History of Time",
    author: "Stephen Hawking",
    price: 17.25,
    category: "Science",
    rating: 4.5,
    description:
      "From the Big Bang to black holes, a clear tour of the universe's biggest questions.",
    coverFrom: "oklch(0.4 0.12 250)",
    coverTo: "oklch(0.25 0.1 255)",
  },
  {
    id: 5,
    title: "Educated",
    author: "Tara Westover",
    price: 16.99,
    category: "Non-Fiction",
    rating: 4.5,
    description:
      "A memoir of a young woman who left her survivalist family and pursued education across the world.",
    coverFrom: "oklch(0.5 0.13 200)",
    coverTo: "oklch(0.34 0.11 210)",
  },
  {
    id: 6,
    title: "The Very Hungry Caterpillar",
    author: "Eric Carle",
    price: 9.99,
    category: "Children",
    rating: 5,
    description:
      "A beloved picture book following a caterpillar eating its way through the week.",
    coverFrom: "oklch(0.72 0.16 130)",
    coverTo: "oklch(0.55 0.15 135)",
  },
  {
    id: 7,
    title: "Dune",
    author: "Frank Herbert",
    price: 21.5,
    category: "Fiction",
    rating: 4.5,
    description:
      "An epic of politics, ecology and prophecy set on the desert planet Arrakis.",
    coverFrom: "oklch(0.65 0.13 70)",
    coverTo: "oklch(0.45 0.12 75)",
  },
  {
    id: 8,
    title: "The Power of Now",
    author: "Eckhart Tolle",
    price: 15.75,
    category: "Self-Help",
    rating: 4,
    description:
      "A guide to spiritual enlightenment and living fully in the present moment.",
    coverFrom: "oklch(0.55 0.12 95)",
    coverTo: "oklch(0.4 0.1 100)",
  },
  {
    id: 9,
    title: "Cosmos",
    author: "Carl Sagan",
    price: 18.0,
    category: "Science",
    rating: 5,
    description:
      "A personal voyage through the universe, its history and its wonders.",
    coverFrom: "oklch(0.35 0.1 260)",
    coverTo: "oklch(0.22 0.08 265)",
  },
  {
    id: 10,
    title: "Where the Wild Things Are",
    author: "Maurice Sendak",
    price: 11.25,
    category: "Children",
    rating: 4.5,
    description:
      "A classic tale of Max's journey to a land where wild things roared their terrible roars.",
    coverFrom: "oklch(0.5 0.13 30)",
    coverTo: "oklch(0.35 0.11 35)",
  },
  {
    id: 11,
    title: "Guns, Germs, and Steel",
    author: "Jared Diamond",
    price: 20.0,
    category: "History",
    rating: 4,
    description:
      "How geography and environment shaped the fates of human societies across millennia.",
    coverFrom: "oklch(0.5 0.12 55)",
    coverTo: "oklch(0.34 0.1 60)",
  },
  {
    id: 12,
    title: "Becoming",
    author: "Michelle Obama",
    price: 18.5,
    category: "Non-Fiction",
    rating: 5,
    description:
      "The deeply personal memoir of a First Lady, her roots, and her years in public life.",
    coverFrom: "oklch(0.48 0.13 350)",
    coverTo: "oklch(0.32 0.11 340)",
  },
];
