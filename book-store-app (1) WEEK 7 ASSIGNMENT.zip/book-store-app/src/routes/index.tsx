import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import Header from "../components/Header";
import SearchBar from "../components/SearchBar";
import Category from "../components/Category";
import BookList from "../components/BookList";
import Footer from "../components/Footer";
import { books, categories } from "../data/books";
import bookstoreHero from "../assets/bookstore-hero.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Online Book Store" },
      { name: "description", content: "Browse, discover and buy books online with categories, search and ratings." },
      { property: "og:title", content: "Online Book Store" },
      { property: "og:description", content: "Browse, discover and buy books online with categories, search and ratings." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredBooks = useMemo(() => {
    const q = query.trim().toLowerCase();
    return books.filter((book) => {
      const matchesCategory =
        activeCategory === "All" || book.category === activeCategory;
      const matchesQuery =
        q === "" ||
        book.title.toLowerCase().includes(q) ||
        book.author.toLowerCase().includes(q) ||
        book.category.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });
  }, [query, activeCategory]);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header onNavigate={() => setQuery("")} />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <img
          src={bookstoreHero}
          alt="Cozy bookstore interior lined with shelves of books"
          width={1600}
          height={900}
          loading="eager"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/75 to-background/40" />
        <div className="relative mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-28">
          <p className="mb-3 inline-block rounded-full bg-accent/20 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-accent-foreground">
            Online Book Store
          </p>
          <h1 className="font-display text-4xl font-bold leading-tight text-foreground sm:text-6xl">
            Welcome to Online Book Store
          </h1>
          <p className="mt-4 max-w-xl text-base text-foreground/80 sm:text-lg">
            Discover your next great read. Browse thousands of titles across fiction,
            science, history and more — with instant search and curated categories.
          </p>
        </div>
      </section>

      {/* Main */}
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-12 sm:px-6">
        <div className="mx-auto mb-10 max-w-2xl">
          <SearchBar value={query} onChange={setQuery} />
        </div>
        <div className="mb-10">
          <Category
            categories={categories}
            active={activeCategory}
            onSelect={setActiveCategory}
          />
        </div>
        <BookList books={filteredBooks} />
      </main>

      <Footer />
    </div>
  );
}
