type HeaderProps = {
  onNavigate?: (target: string) => void;
};

const navItems = ["Home", "Books", "Categories", "About", "Contact"];

export default function Header({ onNavigate }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-card/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6">
        <a href="#" className="flex items-center gap-2" aria-label="Online Book Store home">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-primary text-primary-foreground font-display text-lg font-bold">
            B
          </span>
          <span className="font-display text-lg font-semibold tracking-tight text-foreground sm:text-xl">
            BookHaven
          </span>
        </a>
        <nav className="hidden gap-1 md:flex">
          {navItems.map((item) => (
            <button
              key={item}
              onClick={() => onNavigate?.(item)}
              className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              {item}
            </button>
          ))}
        </nav>
        <button
          onClick={() => onNavigate?.("Books")}
          className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
        >
          Browse
        </button>
      </div>
    </header>
  );
}
