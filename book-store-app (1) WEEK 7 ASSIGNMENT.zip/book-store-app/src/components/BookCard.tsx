import { useState } from "react";
import type { Book } from "../data/books";
import Rating from "./Rating";

type BookCardProps = {
  book: Book;
};

export default function BookCard({ book }: BookCardProps) {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg">
      <div
        className="book-cover relative aspect-[3/4] flex flex-col justify-end p-5 text-white"
        style={{
          backgroundImage: `linear-gradient(150deg, ${book.coverFrom}, ${book.coverTo})`,
        }}
      >
        <span className="mb-2 inline-flex w-fit rounded-full bg-white/20 px-2.5 py-1 text-xs font-medium backdrop-blur-sm">
          {book.category}
        </span>
        <h3 className="font-display text-xl font-semibold leading-tight drop-shadow-sm">
          {book.title}
        </h3>
        <p className="text-sm text-white/80">{book.author}</p>
      </div>

      <div className="flex flex-1 flex-col gap-3 p-5">
        <Rating rating={book.rating} />
        <p className="line-clamp-2 text-sm text-muted-foreground">
          {showDetails ? book.description : book.description.slice(0, 70) + "…"}
        </p>
        <div className="mt-auto flex items-center justify-between">
          <span className="font-display text-2xl font-semibold text-primary">
            ${book.price.toFixed(2)}
          </span>
        </div>
        <div className="flex gap-2 pt-1">
          <button className="flex-1 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90">
            Buy Now
          </button>
          <button
            onClick={() => setShowDetails((v) => !v)}
            className="flex-1 rounded-lg border border-border bg-background px-4 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-secondary"
          >
            {showDetails ? "Hide" : "View Details"}
          </button>
        </div>
      </div>
    </article>
  );
}
