import type { Book } from "../data/books";
import BookCard from "./BookCard";

type BookListProps = {
  books: Book[];
};

export default function BookList({ books }: BookListProps) {
  if (books.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-card py-16 text-center">
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={1.5}
          className="mb-3 h-12 w-12 text-muted-foreground"
          aria-hidden="true"
        >
          <path d="M3 5a2 2 0 012-2h4v18H5a2 2 0 01-2-2V5z" />
          <path d="M21 5a2 2 0 00-2-2h-4v18h4a2 2 0 002-2V5z" opacity="0.4" />
        </svg>
        <p className="font-display text-lg font-semibold text-foreground">
          No Books Found
        </p>
        <p className="mt-1 text-sm text-muted-foreground">
          Try a different search term or category.
        </p>
      </div>
    );
  }

  return (
    <>
      <p className="mb-4 text-sm font-medium text-muted-foreground">
        {books.length} Book{books.length === 1 ? "" : "s"} Found
      </p>
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {books.map((book) => (
          <BookCard key={book.id} book={book} />
        ))}
      </div>
    </>
  );
}
