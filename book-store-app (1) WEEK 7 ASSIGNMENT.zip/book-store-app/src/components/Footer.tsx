export default function Footer() {
  return (
    <footer className="mt-20 border-t border-border bg-card">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-primary text-primary-foreground font-display text-lg font-bold">
              B
            </span>
            <span className="font-display text-lg font-semibold text-foreground">
              BookHaven
            </span>
          </div>
          <p className="mt-3 text-sm text-muted-foreground">
            Your trusted online book store. Discover thousands of titles across every genre,
            delivered to your door.
          </p>
        </div>
        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-wide text-foreground">
            Explore
          </h3>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><a href="#" className="hover:text-foreground">New Arrivals</a></li>
            <li><a href="#" className="hover:text-foreground">Best Sellers</a></li>
            <li><a href="#" className="hover:text-foreground">Categories</a></li>
            <li><a href="#" className="hover:text-foreground">Gift Cards</a></li>
          </ul>
        </div>
        <div>
          <h3 className="font-display text-sm font-semibold uppercase tracking-wide text-foreground">
            Support
          </h3>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><a href="#" className="hover:text-foreground">Help Center</a></li>
            <li><a href="#" className="hover:text-foreground">Shipping & Returns</a></li>
            <li><a href="#" className="hover:text-foreground">Contact Us</a></li>
            <li><a href="#" className="hover:text-foreground">Track Order</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <p className="mx-auto max-w-6xl px-4 py-5 text-center text-xs text-muted-foreground sm:px-6">
          © {new Date().getFullYear()} BookHaven Online Book Store. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
