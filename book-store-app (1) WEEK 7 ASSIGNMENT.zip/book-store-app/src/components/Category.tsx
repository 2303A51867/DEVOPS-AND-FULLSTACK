type CategoryProps = {
  categories: string[];
  active: string;
  onSelect: (category: string) => void;
};

export default function Category({ categories, active, onSelect }: CategoryProps) {
  return (
    <section aria-label="Book categories" className="w-full">
      <h2 className="mb-4 font-display text-xl font-semibold text-foreground">
        Categories
      </h2>
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => {
          const isActive = category === active;
          return (
            <button
              key={category}
              onClick={() => onSelect(category)}
              className={
                "rounded-full px-4 py-2 text-sm font-medium transition-all " +
                (isActive
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "bg-secondary text-secondary-foreground hover:bg-accent hover:text-accent-foreground")
              }
            >
              {category}
            </button>
          );
        })}
      </div>
    </section>
  );
}
