type RatingProps = {
  rating: number;
};

// Displays a book rating as filled / partial / empty stars.
function Star({ filled, half }: { filled: boolean; half: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-4 w-4"
      fill={filled ? "currentColor" : half ? "url(#half)" : "none"}
      stroke="currentColor"
      strokeWidth={filled || half ? 0 : 1.5}
      aria-hidden="true"
    >
      <path d="M12 2.5l2.9 6.1 6.6.9-4.8 4.6 1.2 6.6L12 18.7 6.1 21.3l1.2-6.6L2.5 9.5l6.6-.9L12 2.5z" />
    </svg>
  );
}

export default function Rating({ rating }: RatingProps) {
  const full = Math.floor(rating);
  const hasHalf = rating - full >= 0.5;
  const empty = 5 - full - (hasHalf ? 1 : 0);

  return (
    <div
      className="flex items-center gap-1 text-accent"
      aria-label={`Rating ${rating} out of 5`}
    >
      <svg width="0" height="0" aria-hidden="true">
        <defs>
          <linearGradient id="half">
            <stop offset="50%" stopColor="currentColor" />
            <stop offset="50%" stopColor="transparent" />
          </linearGradient>
        </defs>
      </svg>
      {Array.from({ length: full }).map((_, i) => (
        <Star key={`f-${i}`} filled half={false} />
      ))}
      {hasHalf && <Star filled={false} half />}
      {Array.from({ length: empty }).map((_, i) => (
        <Star key={`e-${i}`} filled={false} half={false} />
      ))}
      <span className="ml-1 text-sm font-medium text-muted-foreground">
        {rating.toFixed(1)}
      </span>
    </div>
  );
}
